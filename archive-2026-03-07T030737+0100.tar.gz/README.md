For This script we need proxies on this format : {proxy_user}:{proxy_pass}@{proxy_host}:{proxy_port} we can find it here ![PROXY](https://www.webshare.io/features/free-proxy)


pip install -r requirements.txt


مبرمج الاداة : by __minatsukix86__
